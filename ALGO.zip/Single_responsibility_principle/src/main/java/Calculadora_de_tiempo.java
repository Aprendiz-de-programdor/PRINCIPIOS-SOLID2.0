
import java.util.Scanner;


public class Calculadora_de_tiempo {

  
    public static void main(String[] args) {
       Scanner entrada = new Scanner(System.in);
       int Horas_totales;
       int Semanas;
       int dias;
       int horas;
       
       System.out.print("Digite el numero de horas: ");
       Horas_totales = entrada.nextInt();
       
       Semanas = Horas_totales / 168;
       dias = Horas_totales%168 / 24;
       horas = Horas_totales%24;
       
       System.out.println("\nEl equivalente es: ");
       System.out.println("semanas: "+Semanas);
       System.out.println("dias: "+dias);
       System.out.println("horas: "+horas);
    }
    
}
